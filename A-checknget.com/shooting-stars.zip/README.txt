A Pen created at CodePen.io. You can find this one at http://codepen.io/svinkle/pen/rEmIH.

 An idea for a game I had a while back. Never finished it, but this is still kind of cool, right?